package abstracts;

public interface Entity {

}
