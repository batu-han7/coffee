package abstracts;
import entities.Customer;

public interface CustomerService {
    public void Save(Customer customer) throws Exception;
   
}
