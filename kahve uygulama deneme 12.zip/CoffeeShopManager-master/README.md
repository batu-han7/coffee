# CoffeeShopManager #Kodlama.io

Kahve dükkanları için müşteri yönetimi yapan bir sistem yazmak istedim.
Çalışılmak üzere iki firma seçildi ve iki firma da müşterilerini veri tabanına kaydetmek istiyor.
Starbucks müşterileri kaydederken , mutlaka mernis doğrulaması istiyor. Nero ise müşterileri kaydederken böyle bir şey istemiyor.
Starbucks müşteriler için her kahve alımında yıldız kazandırmak istiyor.
