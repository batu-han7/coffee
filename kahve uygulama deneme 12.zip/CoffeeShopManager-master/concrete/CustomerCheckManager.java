package concrete;

import abstracts.CustomerCheckService;
import entities.Customer;

public class CustomerCheckManager implements CustomerCheckService{

	public boolean CheckIfRealPerson(Customer customer) {
		return true;
	}

}
