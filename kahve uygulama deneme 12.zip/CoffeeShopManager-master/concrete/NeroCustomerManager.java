package concrete;

import abstracts.BaseCustomerManager;

public class NeroCustomerManager extends BaseCustomerManager {

}
